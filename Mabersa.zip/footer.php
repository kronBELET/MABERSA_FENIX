<footer>
    <p>&copy; 2023 Mabersa</p>
</footer>