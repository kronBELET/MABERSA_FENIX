<?php
// Include the database connection file
require_once('db_conn.php');
// print_r($_SESSION);
// Initialize the info variable
$signup_info = $login_info = '';
if (isset($_REQUEST['login_please'])) {
    $login_info = '<div class="error">You need to login first!</div>';
}
// Check if the form is submitted
if(isset($_POST['signup'])) {
    // Get the form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Check if email already exists in the database
    $email_check_query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $email_check_query);
    $user = mysqli_fetch_assoc($result);
  
    if (!empty($user)) { // Email already exists
        if ($user['email'] === $email) {
            // Set error message
            $signup_info = '<div class="error">La dirección de correo ya existe!</div>';
        }
    } else { // Email doesn't exist, insert new user into database
        $insert_query = "INSERT INTO users (name, email, password, role) 
                         VALUES('$name', '$email', '$password', '$role')";
        mysqli_query($conn, $insert_query);

        // Set success message
        $signup_info = '<div class="success">Usuario creada con éxito!</div>';
    }
}elseif(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $password = md5($_POST['password']);
  
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);
  
    if(mysqli_num_rows($result) == 1){
      $row = mysqli_fetch_assoc($result);
      $_SESSION['u_id'] = $row['u_id'];
      $_SESSION['name'] = $row['name'];
      $_SESSION['email'] = $row['email'];
      $_SESSION['role'] = $row['role'];
  
      $login_info = "<div class='success'>Inicio de sesión exitoso</div>";
      if ($_SESSION['role'] == 'student') {
        header('location: student_dashboard.php');
      } else {
        header('location: teacher_dashboard.php');
      }
      
    } else {
      $login_info = "<div class='error'>Correo electrónico o contraseña no válidos</div>";
    }
  }
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <title>Mabersa</title>
        <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
    </head>

    <body>
        <?php include('header.php'); ?>
        <main>
            <div class="forms">
                <form action="login.php" method="post">
                    <h2 class="subtitle">Acceso</h2>
                    <?php echo $login_info; ?>
                    <label class="label" for="email">Correo electrónico</label>
                    <input class="input" type="email" id="email" name="email" required>
                    <label class="label" for="password">Contraseña</label>
                    <input class="input" type="password" id="password" name="password" required>
                    <input class="submit" type="submit" value="Acceso" name="login">
                </form>
                <form action="login.php" method="post">
                    <h2 class="subtitle">Signup</h2>
                    <?php echo $signup_info; ?>
                    <label class="label" for="name">Nombre</label>
                    <input class="input" type="text" id="name" name="name" required>
                    <label class="label" for="email">Correo electrónico</label>
                    <input class="input" type="email" id="email" name="email" required>
                    <label class="label" for="password">Contraseña</label>
                    <input class="input" type="password" id="password" name="password" required>
                    <label class="label" for="role">Role</label>
                    <select class="select" id="role" name="role" required>
                        <option value="">Select a role</option>
                        <option value="teacher">Maestro/Maestra</option>
                        <option value="student">Alumno/Alumna</option>
                    </select>
                    <input class="submit" type="submit" name="signup" value="Inscribirse">
                </form>
            </div>
        </main>
        <?php include('footer.php'); ?>
    </body>

</html>